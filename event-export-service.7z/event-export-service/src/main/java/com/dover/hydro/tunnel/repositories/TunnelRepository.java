package com.dover.hydro.tunnel.repositories;

import java.util.Date;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.dover.hydro.tunnel.entites.EstadisticaTunnel;

@Repository
public interface TunnelRepository extends JpaRepository<EstadisticaTunnel, String> {

    @Query(value = "from EstadisticaTunnel t where eventDate BETWEEN :startDate AND :endDate")
    List<EstadisticaTunnel> getAllBetweenEventDates(Date startDate, Date endDate);

    List<EstadisticaTunnel> findByModSendStatus(String status);

    List<EstadisticaTunnel> findByModSendStatusIsNull();

    // @Query(value = "from EstadisticaTunnel t where modSendStatus :status AND
    // eventDate BETWEEN :startDate AND :endDate ")
    // List<EstadisticaTunnel> getAllByStatusAndBetweenEventDates(String status,
    // Date startDate, Date endDate);

}
