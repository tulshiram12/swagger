package com.dover.hydro.tunnel.entites;

import java.io.Serializable;
import java.math.BigDecimal;
import java.math.BigInteger;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

/**
 * The persistent class for the estadisticas database table.
 * 
 */
@Entity
@Table(name = "estadisticas")
@NamedQuery(name = "Estadistica.findAll", query = "SELECT e FROM EstadisticaTunnel e")
public class EstadisticaTunnel implements Serializable {
    private static final long serialVersionUID = 1L;

    @Id
    private String id;

    private int alarm;

    @Column(name = "an_1")
    private BigDecimal an1;

    @Column(name = "an_2")
    private BigDecimal an2;

    private int batch;

    private int channel;

    @Column(name = "cost_estimated")
    private BigDecimal costEstimated;

    @Column(name = "cost_real")
    private BigDecimal costReal;

    private int customer;

    private BigDecimal dose;

    @Temporal(TemporalType.TIMESTAMP)
    @Column(name = "event_date")
    private Date eventDate;

    @Column(name = "event_type")
    private int eventType;

    @Column(name = "formula_id")
    private int formulaId;

    @Column(name = "formula_name")
    private String formulaName;

    @Column(name = "gr_estimated")
    private int grEstimated;

    @Column(name = "gr_real")
    private int grReal;

    private int info;

    @Column(name = "laundry_id")
    private BigInteger laundryId;

    @Column(name = "ml_estimated")
    private int mlEstimated;

    @Column(name = "ml_real")
    private int mlReal;

    @Column(name = "mod_send_status")
    private String modSendStatus;

    private int module;

    @Column(name = "product_id")
    private int productId;

    @Column(name = "product_name")
    private String productName;

    @Column(name = "product_price")
    private BigDecimal productPrice;

    @Column(name = "real_kg")
    private int realKg;

    @Temporal(TemporalType.TIMESTAMP)
    @Column(name = "send_date")
    private Date sendDate;

    @Column(name = "time_estimated")
    private BigDecimal timeEstimated;

    @Column(name = "time_real")
    private BigDecimal timeReal;

    @Column(name = "transfer_number")
    private int transferNumber;

    @Column(name = "unit_id")
    private BigInteger unitId;

    public EstadisticaTunnel() {
    }

    public String getId() {
	return id;
    }

    public void setId(String id) {
	this.id = id;
    }

    public int getAlarm() {
	return alarm;
    }

    public void setAlarm(int alarm) {
	this.alarm = alarm;
    }

    public BigDecimal getAn1() {
	return an1;
    }

    public void setAn1(BigDecimal an1) {
	this.an1 = an1;
    }

    public BigDecimal getAn2() {
	return an2;
    }

    public void setAn2(BigDecimal an2) {
	this.an2 = an2;
    }

    public int getBatch() {
	return batch;
    }

    public void setBatch(int batch) {
	this.batch = batch;
    }

    public int getChannel() {
	return channel;
    }

    public void setChannel(int channel) {
	this.channel = channel;
    }

    public BigDecimal getCostEstimated() {
	return costEstimated;
    }

    public void setCostEstimated(BigDecimal costEstimated) {
	this.costEstimated = costEstimated;
    }

    public BigDecimal getCostReal() {
	return costReal;
    }

    public void setCostReal(BigDecimal costReal) {
	this.costReal = costReal;
    }

    public int getCustomer() {
	return customer;
    }

    public void setCustomer(int customer) {
	this.customer = customer;
    }

    public BigDecimal getDose() {
	return dose;
    }

    public void setDose(BigDecimal dose) {
	this.dose = dose;
    }

    public Date getEventDate() {
	return eventDate;
    }

    public void setEventDate(Date eventDate) {
	this.eventDate = eventDate;
    }

    public int getEventType() {
	return eventType;
    }

    public void setEventType(int eventType) {
	this.eventType = eventType;
    }

    public int getFormulaId() {
	return formulaId;
    }

    public void setFormulaId(int formulaId) {
	this.formulaId = formulaId;
    }

    public String getFormulaName() {
	return formulaName;
    }

    public void setFormulaName(String formulaName) {
	this.formulaName = formulaName;
    }

    public int getGrEstimated() {
	return grEstimated;
    }

    public void setGrEstimated(int grEstimated) {
	this.grEstimated = grEstimated;
    }

    public int getGrReal() {
	return grReal;
    }

    public void setGrReal(int grReal) {
	this.grReal = grReal;
    }

    public int getInfo() {
	return info;
    }

    public void setInfo(int info) {
	this.info = info;
    }

    public BigInteger getLaundryId() {
	return laundryId;
    }

    public void setLaundryId(BigInteger laundryId) {
	this.laundryId = laundryId;
    }

    public int getMlEstimated() {
	return mlEstimated;
    }

    public void setMlEstimated(int mlEstimated) {
	this.mlEstimated = mlEstimated;
    }

    public int getMlReal() {
	return mlReal;
    }

    public void setMlReal(int mlReal) {
	this.mlReal = mlReal;
    }

    public String getModSendStatus() {
	return modSendStatus;
    }

    public void setModSendStatus(String modSendStatus) {
	this.modSendStatus = modSendStatus;
    }

    public int getModule() {
	return module;
    }

    public void setModule(int module) {
	this.module = module;
    }

    public int getProductId() {
	return productId;
    }

    public void setProductId(int productId) {
	this.productId = productId;
    }

    public String getProductName() {
	return productName;
    }

    public void setProductName(String productName) {
	this.productName = productName;
    }

    public BigDecimal getProductPrice() {
	return productPrice;
    }

    public void setProductPrice(BigDecimal productPrice) {
	this.productPrice = productPrice;
    }

    public int getRealKg() {
	return realKg;
    }

    public void setRealKg(int realKg) {
	this.realKg = realKg;
    }

    public Date getSendDate() {
	return sendDate;
    }

    public void setSendDate(Date sendDate) {
	this.sendDate = sendDate;
    }

    public BigDecimal getTimeEstimated() {
	return timeEstimated;
    }

    public void setTimeEstimated(BigDecimal timeEstimated) {
	this.timeEstimated = timeEstimated;
    }

    public BigDecimal getTimeReal() {
	return timeReal;
    }

    public void setTimeReal(BigDecimal timeReal) {
	this.timeReal = timeReal;
    }

    public int getTransferNumber() {
	return transferNumber;
    }

    public void setTransferNumber(int transferNumber) {
	this.transferNumber = transferNumber;
    }

    public BigInteger getUnitId() {
	return unitId;
    }

    public void setUnitId(BigInteger unitId) {
	this.unitId = unitId;
    }

    public static long getSerialversionuid() {
	return serialVersionUID;
    }

    @Override
    public String toString() {
	return "EstadisticaTunnel [id=" + id + ", alarm=" + alarm + ", an1=" + an1 + ", an2=" + an2 + ", batch=" + batch
		+ ", channel=" + channel + ", costEstimated=" + costEstimated + ", costReal=" + costReal + ", customer="
		+ customer + ", dose=" + dose + ", eventDate=" + eventDate + ", eventType=" + eventType + ", formulaId="
		+ formulaId + ", formulaName=" + formulaName + ", grEstimated=" + grEstimated + ", grReal=" + grReal
		+ ", info=" + info + ", laundryId=" + laundryId + ", mlEstimated=" + mlEstimated + ", mlReal=" + mlReal
		+ ", modSendStatus=" + modSendStatus + ", module=" + module + ", productId=" + productId
		+ ", productName=" + productName + ", productPrice=" + productPrice + ", realKg=" + realKg
		+ ", sendDate=" + sendDate + ", timeEstimated=" + timeEstimated + ", timeReal=" + timeReal
		+ ", transferNumber=" + transferNumber + ", unitId=" + unitId + "]";
    }

}