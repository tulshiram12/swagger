package com.dover.hydro.controller;

import java.net.URISyntaxException;
import java.text.ParseException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.dover.hydro.service.EventService;
import com.dover.hydro.tunnel.entites.EstadisticaTunnel;
import com.dover.hydro.washer.entites.Estadistica;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;

@Api(value = "EventExportController", description = "REST Apis related to Events in Edge Database!!!!")
@RestController
public class EventExportController {

    @Autowired
    EventService eventService;

    /*
     * @ApiOperation(value = "Get list of event in laundrytec DB")
     * 
     * @GetMapping("/events/washer") public List<Estadistica> getWasherEvents()
     * throws URISyntaxException {
     * 
     * return eventService.findAll(); }
     * 
     * @GetMapping("/events/tunnel")
     * 
     * @ApiOperation(value = "Get list of Event in tunnel DB") public
     * List<EstadisticaTunnel> gettunnelEvents() throws URISyntaxException {
     * 
     * return eventService.findTunnelEvents(); }
     */

    @GetMapping("/washer/events")
    @ApiOperation(value = "Get list of Event By Date laundrytec DB")
    public List<Estadistica> getwasherEventsByDate(
	    @ApiParam(name = "startDate", value = " yyyy-MM-dd HH:mm:ss", defaultValue = "") @RequestParam("startDate") String startDate,
	    @ApiParam(name = "endDate", value = " yyyy-MM-dd HH:mm:ss ", defaultValue = "") @RequestParam("endDate") String endDate)
	    throws URISyntaxException, ParseException {

	return eventService.findWasherByDate(startDate, endDate);
    }

    @GetMapping("/tunnel/events")
    @ApiOperation(value = "Get list of Event By Date from tunnel DB")
    public List<EstadisticaTunnel> gettunnelEventsByDate(
	    @ApiParam(name = "startDate", value = " yyyy-MM-dd HH:mm:ss", defaultValue = "") @RequestParam("startDate") String startDate,
	    @ApiParam(name = "endDate", value = " yyyy-MM-dd HH:mm:ss ", defaultValue = "") @RequestParam("endDate") String endDate)
	    throws URISyntaxException, ParseException {

	return eventService.findTunnelEventsByDate(startDate, endDate);
    }

    @GetMapping("/tunnel/events/{status}")
    @ApiOperation(value = "Get list of Event By status from tunnel DB")
    public List<EstadisticaTunnel> gettunnelEventsBySentStatus(@PathVariable String status) {

	return eventService.findTunnelEventsSentStatus(status);
    }

    @GetMapping("/washer/events/{status}")
    @ApiOperation(value = "Get list of Event By status from laundrytec DB")
    public List<Estadistica> getwasherEventsBySentStatus(@PathVariable String status) {

	return eventService.getWasherEventsSentStatus(status);
    }

  /* @GetMapping("/tunnel/")
    @ApiOperation(value = "Get list of Event By Date and status from tunnel DB")
    public List<EstadisticaTunnel> gettunnelEventsByDateAndStatus(@PathVariable String status,
	    @ApiParam(name = "startDate", value = " yyyy-MM-dd HH:mm:ss", defaultValue = "") @RequestParam("startDate") String startDate,
	    @ApiParam(name = "endDate", value = " yyyy-MM-dd HH:mm:ss ", defaultValue = "") @RequestParam("endDate") String endDate)
	    throws URISyntaxException, ParseException {

	return eventService.findTunnelEventsByDateAndStatus(startDate, endDate, status);
    }*/
}
