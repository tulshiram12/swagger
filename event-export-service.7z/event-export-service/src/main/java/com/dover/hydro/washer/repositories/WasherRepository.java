package com.dover.hydro.washer.repositories;

import java.util.Date;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.dover.hydro.washer.entites.Estadistica;

@Repository
public interface WasherRepository extends JpaRepository<Estadistica, String> {

    List<Estadistica> findByeventType(int eventType);

    @Query(value = "from Estadistica t where eventDate BETWEEN :startDate AND :endDate")
    public List<Estadistica> getAllBetweenEventDates(@Param("startDate") Date startDate,
	    @Param("endDate") Date endDate);

    List<Estadistica> findByModSendStatus(String status);

    List<Estadistica> findByModSendStatusIsNull();
}
