package com.dover.hydro;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EventExportServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(EventExportServiceApplication.class, args);
	}

}
